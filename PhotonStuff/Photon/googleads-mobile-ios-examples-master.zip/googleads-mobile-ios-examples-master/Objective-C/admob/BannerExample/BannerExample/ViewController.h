// Copyright (c) 2014 Google. All rights reserved.

#import <UIKit/UIKit.h>

@class GADBannerView;

@interface ViewController : UIViewController

@property(nonatomic, weak) IBOutlet GADBannerView *bannerView;

@end
