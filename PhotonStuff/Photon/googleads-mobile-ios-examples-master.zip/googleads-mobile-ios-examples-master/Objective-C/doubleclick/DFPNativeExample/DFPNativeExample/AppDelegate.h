//  Copyright (c) 2015 Google. All rights reserved.

@import UIKit;

@interface AppDelegate : UIResponder<UIApplicationDelegate>

@property(strong, nonatomic) UIWindow *window;

@end
